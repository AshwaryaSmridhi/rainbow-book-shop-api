// data.ts

import fs from 'fs';
import { Book, Order } from './types';

const BOOKS_FILE = './data/books.json';
const ORDERS_FILE = './data/orders.json';

// Read books from the JSON file
export function readBooks() {
  const booksData = fs.readFileSync(BOOKS_FILE, 'utf8');
  return JSON.parse(booksData);
}

// Write books to the JSON file
export function writeBooks(books: Book[]) {
  fs.writeFileSync(BOOKS_FILE, JSON.stringify(books, null, 2));
}

// Read orders from the JSON file
export function readOrders() {
  const ordersData = fs.readFileSync(ORDERS_FILE, 'utf8');
  return JSON.parse(ordersData);
}

// Write orders to the JSON file
export function writeOrders(orders: Order[]) {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
}
